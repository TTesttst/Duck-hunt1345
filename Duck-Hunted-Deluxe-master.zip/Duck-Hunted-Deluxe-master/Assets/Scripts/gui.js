#pragma strict

public var playerTransform : Player;

function Start () 
{

}

function Update () 
{	

}