#pragma strict

function Start () {
	guiText.text = "A Game By\nPatrik 'Svampson' Riström\nPhill 'Pfhreak' Spiess\nMade for the 7DFPS compo!";
}

function Update () {

}