Yo! This is a test! - Svampson

Copyright notices:

iTween: MIT License. Project is hosted: http://code.google.com/p/itween/
Duckhunt Font: Free for Personal Use, Copyright (c) Joseph Spicer